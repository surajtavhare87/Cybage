//3) Give an example of ListIterator.
package collection;

import java.util.ArrayList;
/*
public class ListIterator {
	public static void main(String[] args) {    
		ArrayList<String> arrlist = new ArrayList<String>();  
		arrlist.add("d");  
		arrlist.add("dd");  ss
		arrlist.add("ddd");  
		arrlist.add("dddd");  
		arrlist.add("ddddd");  
		System.out.println(arrlist);    // [d, dd, ddd, dddd, ddddd]  
		ListIterator<String> iterator = arrlist.listIterator(5);  
		System.out.println(iterator.hasNext ());    // false  
		iterator =  arrlist.listIterator(6);    // IndexOutOfBoundsException  
		  
		}  

}*/
