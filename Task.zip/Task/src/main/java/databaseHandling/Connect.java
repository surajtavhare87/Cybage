//Write a program to make a connection to the database . 
//Execute a query and store the retrieved data in excel sheet. Save the excel with current timestamp
package databaseHandling;

public class Connect {

	public static void main(String[] args) {
	

