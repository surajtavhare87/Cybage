package operator;

public class Arithmetic {
	
	public static void main(String[] args) {
		int a = 12, b = 5;   //Instance Variable
		
		// addition operator
		System.out.println("a + b = " + (a + b));

		// subtraction operator
		System.out.println("a - b = " + (a - b));

		// multiplication operator
		System.out.println("a * b = " + (a * b));

		// division operator
		System.out.println("a / b = " + (a / b));

		// modulo operator
		System.out.println("a % b = " + (a % b));

	}
}		
	


