package operator;

public class variable {
	    int data=50;//instance variable  
	    static int m=100;//static variable  
	    public static void main(String args[])
	    {
	    	System.out.println(m);
	    }
        void method()
        {  
        // int n=90;//local variable  
        }
	}


