package operator;

public class Relational {
	public static void main(String[] args) {
	 // create variables
    int a = 7, b = 11;

    // == operator
    System.out.println(a == b);  

    // != operator
    System.out.println(a != b);  

    // > operator
    System.out.println(a > b);  

    // < operator
    System.out.println(a < b);  

    // >= operator
    System.out.println(a >= b);  

    // <= operator
    System.out.println(a <= b);  
}
	}
