package widgets;

public class Accordian {

}
