
package forms;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeForm {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;

		System.setProperty("webdriver.chrome.driver", "D:\\Software\\Selenium\\driver98\\chromedriver.exe");

		driver = new ChromeDriver();

		// Maximze
		driver.manage().window().maximize();

		// Open Below Website
		driver.get("https://demoqa.com/");

		// For Scrolling
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)", "");

		// For Forms
		driver.findElement(By.xpath("//h5[contains(text(),'Forms')]")).click();

		// For Practice Form
		driver.findElement(By.xpath("//span[contains(text(),'Practice Form')]")).click();

		// For FirstName
		driver.findElement(By.xpath("//input[@id='firstName']")).sendKeys("Suraj");

		// For LastName
		driver.findElement(By.xpath("//input[@id='lastName']")).sendKeys("Tavhare");

		// For Email
		driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("Suraj@gmail.com");

		// For Gender
		driver.findElement(By.xpath("//label[contains(text(),'Male')]")).click();
		
	/*	//For DOB
	    WebElement dateBox1 = driver.findElement(By.xpath("//input[@id='dateOfBirthInput']"));

	    dateBox1.sendKeys(Keys.CONTROL + "a");
	    dateBox1.sendKeys(Keys.DELETE);
	    //Fill date as mm/dd/yyyy as 09/25/2013

	    dateBox1.sendKeys("27 Jul 2022");
	   // dateBox1.sendKeys(Keys.ENTER);*/
		
		//Selecting the first checkbox using XPath
		driver.findElement(By.xpath("//label[text()='Sports']")).click();

		//Selecting the second checkbox using Xpath
		driver.findElement(By.xpath("//label[text()='Reading']")).click();

		// For MobileNumber
		driver.findElement(By.xpath("//input[@id='userNumber']")).sendKeys("8787878787");

		// For Current Address
		driver.findElement(By.xpath("//textarea[@id='currentAddress']")).sendKeys("Abcde");

		// For Scrolling
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("window.scrollBy(0,500)", "");

		// For Submit
		driver.findElement(By.xpath("//button[@id='submit']")).click();

	}
}